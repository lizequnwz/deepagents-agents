assert 'leaked' not in globals()
combined = datasets['doubled'].copy()
analysis_outputs = {'ratio': 2.0, 'rows': len(combined)}
output_datasets = {'final': combined}
