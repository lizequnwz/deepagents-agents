import matplotlib.pyplot as plt
leaked = 123
frame = datasets['sales'].copy()
frame['amount'] = frame['amount'] * 2
output_datasets = {'doubled': frame}
fig, ax = plt.subplots()
ax.plot([1,2],[float(x) for x in frame['amount']])
ax.set_title('Doubled amounts')
analysis_outputs = {'total': str(frame['amount'].sum()), 'figure': fig}
