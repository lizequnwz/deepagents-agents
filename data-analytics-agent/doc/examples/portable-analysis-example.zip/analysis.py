from pathlib import Path
from replay import replay_all

if __name__ == "__main__":
    replay_all(Path(__file__).resolve().parent)
