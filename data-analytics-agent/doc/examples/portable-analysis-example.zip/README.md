# Portable analysis

Question: Analyze amounts

The complete snapshot has total 24.6800.

## Scope and limitations

Partial findings: False. Extracted populations complete: True.
These are immutable saved snapshots. Source freshness/completeness is established only by an explicit source statement, not by upload time or first/last transaction dates.
SQL appears as provenance; this package does not refresh warehouse data or re-execute SQL transformations.
Chart presentation snapshots may be sampled; their complete parents remain in data/ and the manifest.



## Method

Multiply each complete snapshot amount by two.

Doubled total is 24.6800.


## Run locally

Use a Python environment matching manifest.json. Install dependencies with `python -m pip install -r requirements.txt`, then run `python analysis.py`.
Outputs go into replayed/. Each exact step in steps/ runs in a fresh local process, using explicit named inputs. SQL snapshots remain fixed boundaries. Notebook execution uses the same helper.
Open analysis.ipynb in Jupyter with this extracted folder as the working directory. Run all cells in order; editing a step changes replay code, never the stored evidence.
The HTML report contains the original published charts and narrative. The notebook retains stored compact tables and figures for viewing before replay.
Replay validates typed output datasets with rtol=1e-7 and atol=1e-10. Stochastic methods require explicit seeds in the original code; matching is not guaranteed otherwise. Successful replay alone does not establish methodological correctness.
Dependencies from recorded executions are included where available; versions for older executions are unknown. Custom/dynamic imports or code depending on external files/services require manual review. No environment files or service credentials are bundled.
